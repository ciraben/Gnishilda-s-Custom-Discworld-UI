  __________________________________________________
//   Gnishilda's Discworld plugin for Mudlet 2.1.0, \\
||		featuring transplants from	     ||
|| Akaya's Geyser UI template - Vadi's CSSMan script ||
||		Ghostbird's DiscworldUI		     ||
\\__________________________________________________//
	<< Thanks for trying this out! >>

	   << Set-up Instructions >>

Step 1/
	If you haven't already, install Mudlet 2.1.0 from the Mudlet website.
Step 1.5/
	Download the magical .xml file ;)
Step 2/
	Open Mudlet and create a new profile!
		Discworld server: discworld.starturtle.net
		Port: 4242 (or 23)
Step 3/
	IMPORTANT: Under Settings select "Enable GMCP".
Step 4/
	Open the Package Manager, click Install, select the .xml file (from wherever you saved it on your computer) and click OK.
Step 5/
	Restart Mudlet - "Save Profile" when it prompts you on closing. When you reenter the MUD, type "look", "score", "look medium satchel" (if you have one) to start using the sidebars!

Step 6/
	TROUBLESHOOTING:
	(You may have to restart Mudlet for changes to take effect.)

	Recommended Discworld MUD settings:
		options output map:
			frame = on (IMPORTANT for map sidewindow updates)
			glance = off
			glancecity = off
			look = off
			lookcity = off
		options mxp enabled = on (IMPORTANT for mini text windows)
		options output map mxp = off (if map is colour)

Good luck! :)